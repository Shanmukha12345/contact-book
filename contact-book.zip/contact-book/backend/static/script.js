// DOM Elements 
const contactForm = document.getElementById("contactForm");
const contactList = document.getElementById("contactList");
const searchQuery = document.getElementById("searchQuery");

const API = "http://127.0.0.1:5000";
let contacts = [];
let sortAsc = true;

// Load Contacts from Backend
window.onload = async () => {
  try {
    const res = await fetch(`${API}/contacts`);
    contacts = await res.json();
    renderContacts();
    birthdayReminder();
  } catch (error) {
    console.error("Failed to load contacts from backend:", error);
    loadContactsFromLocal();
    birthdayReminder();
  }
};

// Add Contact
contactForm.addEventListener("submit", async function (e) {
  e.preventDefault();

  const newContact = {
    id: document.getElementById("id").value.trim(),
    firstName: document.getElementById("firstName").value.trim(),
    lastName: document.getElementById("lastName").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    email: document.getElementById("email").value.trim(),
    category: document.getElementById("category").value.trim(),
    country: document.getElementById("country").value.trim(),
    favorite: false,
    birthday: document.getElementById("birthday")?.value.trim() || ""
  };

  if (hasDuplicate(newContact)) {
    alert("Duplicate contact (same email & phone) not allowed.");
    return;
  }

  contacts.push(newContact);
  saveContactsToLocal();
  renderContacts();
  contactForm.reset();

  try {
    await fetch("http://127.0.0.1:5000/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newContact)
});

  } catch (error) {
    console.error("Failed to add contact to backend:", error);
  }
});

// Render Contact List
function renderContacts(list = contacts) {
  contactList.innerHTML = "";
  list.forEach((contact, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
  <td>${contact.favorite ? '★' : '☆'}</td>
  <td>${contact.id}</td>
  <td>${contact.firstName}</td>
  <td>${contact.lastName}</td>
  <td>${contact.phone}</td>
  <td>${contact.email}</td>
  <td>${contact.category}</td>
  <td>${contact.country}</td>
  <td>
    <button onclick="editContact(${index})">Edit</button>
    <button onclick="deleteContact(${index})">Delete</button>
    <button onclick="toggleFavorite(${index})">${contact.favorite ? '★' : '☆'}</button>
  </td>
`;
    contactList.appendChild(row);
  });
}

// Search
async function searchContact() {
  const q = searchQuery.value.toLowerCase();
  try {
    const res = await fetch(`${API}/contacts`);
    const allContacts = await res.json();
    const filtered = allContacts.filter(
      c => c.firstName.toLowerCase().includes(q) ||
           c.lastName.toLowerCase().includes(q) ||
           c.email.toLowerCase().includes(q) ||
           c.phone.includes(q)
    );
    renderContacts(filtered);
  } catch (error) {
    console.error("Failed to search contacts from backend:", error);
  }
}

// Edit Contact
function editContact(index) {
  const c = contacts[index];
  document.getElementById("id").value = c.id;
  document.getElementById("firstName").value = c.firstName;
  document.getElementById("lastName").value = c.lastName;
  document.getElementById("phone").value = c.phone;
  document.getElementById("email").value = c.email;
  document.getElementById("category").value = c.category;
  document.getElementById("country").value = c.country;
  deleteContact(index);
}

// Delete Contact
async function deleteContact(index) {
  const contact = contacts[index];
  contacts.splice(index, 1);
  saveContactsToLocal();
  renderContacts();

  try {
    await fetch(`${API}/delete/${contact.id}`, {
      method: "DELETE"
    });
  } catch (error) {
    console.error("Failed to delete contact from backend:", error);
  }
}

// Toggle Favorite
function toggleFavorite(index) {
  contacts[index].favorite = !contacts[index].favorite;
  saveContactsToLocal();
  renderContacts();
}

// Export to CSV
function exportCSV() {
  let csv = "ID,First Name,Last Name,Phone,Email,Category,Country\n";
  contacts.forEach(c => {
    csv += `${c.id},${c.firstName},${c.lastName},${c.phone},${c.email},${c.category},${c.country}\n`;
  });
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "contacts.csv";
  a.click();
}

// Import from CSV
document.getElementById("csvInput")?.addEventListener("change", function (event) {
  const file = event.target.files[0];
  const reader = new FileReader();
  reader.onload = function (e) {
    const lines = e.target.result.split("\n");
    lines.slice(1).forEach(line => {
      const [id, firstName, lastName, phone, email, category, country] = line.split(",");
      if (id && firstName) {
        contacts.push({
          id, firstName, lastName, phone, email, category, country,
          favorite: false
        });
      }
    });
    saveContactsToLocal();
    renderContacts();
  };
  reader.readAsText(file);
});

// Sort A-Z/Z-A
function sortContactsByName() {
  contacts.sort((a, b) => {
    const nameA = (a.firstName + a.lastName).toLowerCase();
    const nameB = (b.firstName + b.lastName).toLowerCase();
    return sortAsc ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
  });
  sortAsc = !sortAsc;
  renderContacts();
}

// Filter by Category
function filterByCategory(category) {
  const filtered = contacts.filter(c => c.category.toLowerCase() === category.toLowerCase());
  renderContacts(filtered);
}

// Filter by Country
function filterByCountry(country) {
  const filtered = contacts.filter(c => c.country.toLowerCase() === country.toLowerCase());
  renderContacts(filtered);
}

// Recently Added
function getRecentContacts() {
  const recent = contacts.slice(-5).reverse();
  renderContacts(recent);
}

// Birthday Reminder
function birthdayReminder() {
  const today = new Date().toISOString().slice(5, 10);
  const upcoming = contacts.filter(c => c.birthday?.slice(5, 10) === today);
  if (upcoming.length) {
    alert(`🎂 Today's birthdays:\n${upcoming.map(c => c.firstName + " " + c.lastName).join("\n")}`);
  }
}

// Duplicate Check
function hasDuplicate(newContact) {
  return contacts.some(c => c.email === newContact.email && c.phone === newContact.phone);
}

// Local Storage
function saveContactsToLocal() {
  localStorage.setItem('contacts', JSON.stringify(contacts));
}

function loadContactsFromLocal() {
  const data = localStorage.getItem('contacts');
  if (data) {
    contacts = JSON.parse(data);
    renderContacts();
  }
}
