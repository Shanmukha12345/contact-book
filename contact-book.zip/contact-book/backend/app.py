from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)

DATA_FILE = "../data/contacts.txt"

# Helpers
def read_contacts():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, 'r') as f:
        lines = [line.strip().split(',') for line in f.readlines()]
    return [
        {
            "id": parts[0],
            "firstName": parts[1],
            "lastName": parts[2],
            "phone": parts[3],
            "email": parts[4],
            "category": parts[5],
            "country": parts[6],
        } for parts in lines if len(parts) >= 7
    ]

def write_contacts(contact_list):
    with open(DATA_FILE, 'w') as f:
        for c in contact_list:
            line = ','.join([
                c['id'], c['firstName'], c['lastName'], c['phone'],
                c['email'], c['category'], c['country']
            ])
            f.write(line + '\n')

# ✅ Frontend route
@app.route("/")
def index():
    return render_template("index.html")

# ✅ Backend APIs
@app.route("/contacts", methods=["GET"])
def get_contacts():
    return jsonify(read_contacts())

@app.route("/add", methods=["POST"])
def add_contact():
    data = request.json
    contacts = read_contacts()
    contacts.append(data)
    write_contacts(contacts)
    return jsonify({"status": "added"})

@app.route("/delete/<id>", methods=["DELETE"])
def delete_contact(id):
    contacts = read_contacts()
    contacts = [c for c in contacts if c['id'] != id]
    write_contacts(contacts)
    return jsonify({"status": "deleted"})

if __name__ == "__main__":
    app.run(debug=True)
